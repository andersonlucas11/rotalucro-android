# RotaLucro Seguro — versão 0.2 (teste)

Essa variante foi preparada após o bloqueio da instalação da versão 0.1 pelo Google Play Protect.

## O que faz
- Painel de faturamento, quilômetros, tempo, ganhos Uber/99, R$/km e R$/hora.
- Salva dados **apenas no próprio dispositivo**, sem internet.
- Só adiciona uma corrida se o usuário informa valor, km e duração e marca a declaração explícita de que ela foi CONCLUÍDA no histórico da Uber/99.
- Corridas canceladas não devem ser cadastradas. Esta versão NÃO faz detecção automática de finalização.
- Não solicita permissões de acessibilidade, SMS, notificações ou localização.

## O que ainda falta
O monitoramento AUTOMÁTICO de "Finalizar UberX"/"Cobrar pagamento" depende de acesso controlado às informações de outros aplicativos, tipicamente por um serviço de acessibilidade, que está removido desta versão de testes. Um APK distribuído fora da Play Store com esse serviço pode ser bloqueado pelo Play Protect. Para liberar o recurso de modo responsável é necessário implementar divulgação adequada de privacidade e investigar uma distribuição verificada e a compatibilidade com as políticas da Google Play e das plataformas de transporte. Publicação/análise podem levar mais do que 30 minutos.

## Compilar no GitHub

1. Envie o projeto (todos os arquivos na raiz) ao repositório.
2. Em **Actions**, abra **Gerar APK Seguro (sem acessibilidade)**. Execute se não iniciar automaticamente.
3. Depois do sinal verde, baixe o artefato **RotaLucro-Seguro-APK** e extraia `app-debug.apk`.
4. O APK é assinado com a chave de debug do ambiente de compilação para testes; **não é versão de produção**. Essa chave pode mudar em compilações futuras, impedindo atualização direta sem reinstalar.
5. Não desative o Play Protect. Ele ainda pode avisar sobre APKs desconhecidos; caso apareça bloqueio, não force instalação, registre a tela.

Esta versão é um aplicativo independente e **não oficial**, sem afiliação com Uber/99. Proteja o APK e confira os dados no histórico oficial.
